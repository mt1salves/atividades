public class Automovel extends Veiculo {
    public Automovel () {
        System.out.println("Automovel");    
    }
    
    public void checkList() {
        System.out.println("Automovel.checkList");
    }
    
    public void adjust () {
        System.out.println("Automovel.adjust");
    }
    
    public void cleanup () {
        System.out.println("Automovel.cleanup");
    }
}