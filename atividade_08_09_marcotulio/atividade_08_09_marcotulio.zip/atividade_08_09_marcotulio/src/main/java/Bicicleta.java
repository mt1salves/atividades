public class Bicicleta extends Veiculo {
    public Bicicleta () {
        System.out.println("Bicicleta");    
    }
    
    public void checkList() {
        System.out.println("Bicicleta.checkList");
    }
    
    public void adjust () {
        System.out.println("Bicicleta.adjust");
    }
    
    public void cleanup () {
        System.out.println("Bicicleta.cleanup");
    }
}  
