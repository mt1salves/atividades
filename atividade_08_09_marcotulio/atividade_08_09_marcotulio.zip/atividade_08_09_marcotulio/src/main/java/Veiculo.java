import java.util.*;

public class Veiculo {
    public Veiculo () {
        System.out.println("Veiculo");    
    }
    
    public void checkList() {
        System.out.println("Veiculo.checList");
    }
    
    public void adjust () {
        System.out.println("Veiculo.adjust");
    }
    
    public void cleanup () {
        System.out.println("Veiculo.cleanup");
    }
}
